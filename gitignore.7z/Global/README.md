## Globally Useful gitignores

This directory contains globally useful gitignores,
e.g. OS-specific and editor specific.

For more on global gitignores:
<http://help.github.com/git-ignore/>

And a good blog post about 'em:
<http://augustl.com/blog/2009/global_gitignores>
